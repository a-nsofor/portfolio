<?php
// phpcs:disable Generic.Files.LineLength.MaxExceeded                              
// phpcs:disable Generic.Files.LineLength.TooLong                                  

// Fallback template, in case JS fails to override the WP2Static submenu item

?>

<div class="wrap">
    <h1>Try 1-Click static site publishing!</h1>

    <p>Loving WP2Static but want to try 1-Click Publish on Strattic?</p>

    <p><a href="https://link.strattic.com/one-click-deploy">Click here</a> to try Strattic for free today!</p>

</div>
